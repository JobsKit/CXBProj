//
//  AppDelegate.m
//  json
//
//  Created by Henry on 6/9/22.
//

#import "AppDelegate.h"
#import "TestModel.h"
#import "NSObject+parser.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    NSArray *jsons = @[@{@"key": @"value"}, @{@"key": @"value"}];
    NSArray *res = [TestModel parser:jsons];
    
    return YES;
}

@end
