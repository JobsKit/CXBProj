//
//  TestModel.h
//  json
//
//  Created by Henry on 6/9/22.
//

#import <Foundation/Foundation.h>


@interface TestModel : NSObject
@property(nonatomic, strong) NSString *key;
@end

