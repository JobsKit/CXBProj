//
//  AppDelegate.h
//  json
//
//  Created by Henry on 6/9/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

