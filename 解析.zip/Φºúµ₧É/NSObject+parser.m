//
//  NSObject+parser.m
//  json
//
//  Created by Henry on 6/9/22.
//

#import "NSObject+parser.h"

@implementation NSObject (parser)

+ (NSArray *)parser:(NSArray *)arr{
    NSMutableArray *res = [NSMutableArray array];
    for(NSDictionary *json in arr) {
        id obj = [[self alloc]init];
        [obj setValuesForKeysWithDictionary:json];
        [res addObject:obj];
    }
    return res;
}

@end
