//
//  NSObject+parser.h
//  json
//
//  Created by Henry on 6/9/22.
//

#import <Foundation/Foundation.h>

@interface NSObject (parser)

+ (NSArray *)parser:(NSArray *)arr;

@end

