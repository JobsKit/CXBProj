//
//  AppDelegate.m
//  Layout
//
//  Created by 上帝的宠儿 on 2022/6/8.
//

#import "AppDelegate.h"

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    CGRect frame = UIScreen.mainScreen.bounds;
    _window = [[UIWindow alloc]initWithFrame:frame];
    UIViewController *vc = [[UIViewController alloc]init];
    _window.rootViewController = vc;
    [_window makeKeyAndVisible];

    return YES;
}


@end
