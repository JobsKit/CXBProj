//
//  ViewController.m
//  Layout
//
//  Created by 上帝的宠儿 on 2022/6/8.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGRect frame = fitTop(100, 80, 200, 200);
    UIView *take = [[UIView alloc]initWithFrame:frame];
    [self.view addSubview:take];
    
    frame = fitHor(20, 20, 100, 60);
    UIView *sub = [[UIView alloc]initWithFrame:frame];
    [take addSubview:sub];
    
    frame = CGRectMake(0, 0, take.w_ - hs(50), hs(120));
    UIView *v = [[UIView alloc]initWithFrame:frame];
    [take addSubview:v];
}


@end
