//
//  AppDelegate.h
//  Layout
//
//  Created by 上帝的宠儿 on 2022/6/8.
//

#import <UIKit/UIKit.h>
#import "layout.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic, strong) UIWindow *window;

@end

